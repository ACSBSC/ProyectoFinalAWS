const mysql = require('mysql');

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

function getRandomRutine() {
    var connection = mysql.createConnection({
        host: 'ur18wij5eq2o2pv.clq9iensdvuy.us-east-1.rds.amazonaws.com',
        user: 'root',
        password: 'password',
        port: '3306'
    });
    connection.connect()
    return new Promise((resolve, reject) => {
        connection.query("SELECT * FROM project.actividades_actividad", (err, result) => {
            let rand = getRandomInt(0, result.length);
            let activity = result[rand];
            let responseBody = {
                nombre: activity.nombre,
                descripcion: activity.descripcion,
                tipo: activity.tipo,
                imagen: activity.imagen
            };
            connection.end();
            let response = {
                statusCode: 200,
                headers: {
                    "x-custom-header": "my custom header value"
                },
                body: JSON.stringify(responseBody)
            };
            resolve(response);
        });
    });
}



exports.handler = async(event) => {
    let res = await getRandomRutine();
    return res;
}