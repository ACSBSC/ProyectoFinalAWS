const AWS = require('aws-sdk');

AWS.config.update({
    region: 'us-east-1'
});

var ddb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });

function getAllTypes() {
    let params = {
        TableName: "categoria_rutinas",
    };
    return new Promise((resolve, reject) => {
        ddb.scan(params, function(err, data) {
            let responseBody;
            if (err) responseBody = err.stack;
            responseBody = data.Items.map(elem => {
                return elem.Tipo.S;
            });
            let response = {
                statusCode: 200,
                headers: {
                    "x-custom-header": "my custom header value"
                },
                body: JSON.stringify(responseBody)
            };
            resolve(response);
        });
    });
}


exports.handler = async(event) => {
    let res = await getAllTypes();
    return res;
}